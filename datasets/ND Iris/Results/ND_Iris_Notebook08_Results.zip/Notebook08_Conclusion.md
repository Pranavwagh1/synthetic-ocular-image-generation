# Notebook 08 — Image Quality and Diversity Evaluation

## Objective
Compare image-level quality statistics and simple diversity proxies for available real, traditional-augmentation, GAN, and diffusion images.

## Evaluation coverage
- Total evaluated images: **555**
- Evaluation errors: **0**
- Sampling limit per group: **500**

- **Real:** 500 evaluated image(s), 6233 discovered file(s).
- **Traditional:** 0 evaluated image(s), 0 discovered file(s).
- **GAN:** 38 evaluated image(s), 38 discovered file(s).
- **Diffusion:** 17 evaluated image(s), 17 discovered file(s).

## Group-level results

| group     |   brightness_mean_mean |   brightness_mean_std |   brightness_mean_median |   contrast_std_mean |   contrast_std_std |   contrast_std_median |   dynamic_range_mean |   dynamic_range_std |   dynamic_range_median |   gradient_energy_mean |   gradient_energy_std |   gradient_energy_median |   laplacian_variance_mean |   laplacian_variance_std |   laplacian_variance_median |   high_frequency_residual_mean |   high_frequency_residual_std |   high_frequency_residual_median |
|:----------|-----------------------:|----------------------:|-------------------------:|--------------------:|-------------------:|----------------------:|---------------------:|--------------------:|-----------------------:|-----------------------:|----------------------:|-------------------------:|--------------------------:|-------------------------:|----------------------------:|-------------------------------:|------------------------------:|---------------------------------:|
| Diffusion |                125.902 |                8.1104 |                  127.876 |             27.546  |             5.034  |               26.6855 |              174.177 |             23.3512 |                  166   |                66.4978 |              159.81   |                  27.4948 |                   289.912 |                  723.089 |                     115.931 |                         4.8727 |                        3.2268 |                           4.0494 |
| GAN       |                132.584 |               15.0438 |                  131.102 |             47.8265 |             9.9184 |               47.4932 |              229.947 |             17.8945 |                  232.5 |               307.802  |              373.276  |                 149.602  |                  1306.66  |                 1849.17  |                     567.424 |                        12.47   |                        5.8585 |                          10.054  |
| Real      |                143.863 |               22.1315 |                  138.454 |             60.6807 |             8.2118 |               59.8553 |              249.656 |              7.9753 |                  254   |               177.239  |               64.8555 |                 164.546  |                   941.521 |                  285.304 |                     919.146 |                         7.2822 |                        1.2653 |                           7.2998 |

## Interpretation
Brightness, contrast, dynamic range, gradient energy, Laplacian variance, and high-frequency residual provide useful low-level image statistics. Across-image variation in these statistics is reported as a diversity proxy. These measures cannot establish whether synthetic images are semantically diverse or realistic.

## Limitations
- Verified contact-lens class labels were unavailable.
- Image-statistic variation is not a substitute for FID, KID, expert review, or task-based evaluation.
- Generated samples may be low-resolution and trained for only a few epochs.
- Do not infer identity preservation, privacy, or clinical suitability from these results.

## Conclusion
This notebook completed an exploratory comparison of the image groups that were available at runtime. Interpret comparisons only for groups with nonzero evaluated counts. Missing groups must not be treated as failed models or as zero-quality images.
