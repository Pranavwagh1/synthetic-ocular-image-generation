# Notebook 13 — Privacy Leakage Analysis

## Objective
Screen generated images for exact normalized matches and nearest-neighbor similarity to a sampled real-image reference set.

## Real reference-set findings
- Real images evaluated: 1500
- Exact duplicate groups after normalization: 2
- Excess images in exact-duplicate groups: 2
- Mean nearest-real pixel distance within reference set: 0.07269977660787602
- Mean nearest-real average-hash Hamming distance: 2.936

## Generated-to-real findings
| group     |   n_images |   exact_matches |   mean_nearest_pixel_distance |   median_nearest_pixel_distance |   mean_nearest_phash_hamming |   low_distance_threshold |   low_distance_count |
|:----------|-----------:|----------------:|------------------------------:|--------------------------------:|-----------------------------:|-------------------------:|---------------------:|
| GAN       |         38 |               0 |                      0.121228 |                        0.111109 |                      8.02632 |                     0.05 |                    0 |
| Diffusion |         17 |               0 |                      0.108067 |                        0.108798 |                     12.5882  |                     0.05 |                    0 |

## Interpretation
Lower nearest-neighbor distances indicate greater low-level similarity under the selected preprocessing. They do not establish that a generated image reveals a training image or identifies a person.

## Limitations
- The real reference set is sampled, not the complete dataset.
- Similarity is measured after grayscale conversion and resizing.
- Average hash and pixel distance are simple screening measures, not validated privacy metrics.
- No verified subject identity labels are available.
- No formal re-identification or target-model membership attack is conducted.

## Conclusion
This notebook provides an exploratory similarity screen for potential memorization signals. Any close matches should be manually reviewed and evaluated with stronger metrics before drawing privacy conclusions. Absence of close matches in this sample does not prove privacy safety.