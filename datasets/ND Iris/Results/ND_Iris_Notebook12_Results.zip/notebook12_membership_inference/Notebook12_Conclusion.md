# Notebook 12 — Membership Inference Attack

## Objective
This notebook runs an exploratory feature-based experiment that classifies randomly assigned image subsets as members or non-members.

## Results
- Valid images: 2500
- Features per image: 1031
- Member examples: 1250
- Non-member examples: 1250
- Attack test examples: 750
- Accuracy: 0.4987
- Precision: 0.4987
- Recall: 0.5120
- F1-score: 0.5053
- ROC-AUC: 0.4999
- Chance baseline accuracy/AUC: 0.5000
- Image loading errors: 0

## Critical Interpretation
Membership was assigned randomly, independently of training a target model. The attack classifier used image features rather than target-model confidence, loss, or prediction behavior. Therefore, this experiment does **not** establish whether the trained recognition model leaks training membership or private identity information.

Any performance above chance can arise from sampling effects, image-feature patterns, or split artifacts. It must not be presented as proof of a privacy vulnerability.

## Limitations
- No verified iris identity or contact-lens labels were used.
- This is not a standard attack against the trained ResNet18.
- A rigorous membership-inference evaluation requires a defined target model, genuine member and non-member sets, and target-model outputs or losses.
- Results are exploratory and do not constitute a privacy or security certification.

## Conclusion
This notebook provides a reproducible baseline for a feature-based membership simulation. It does not demonstrate genuine target-model membership leakage. A proper privacy assessment should attack the trained target model using matched member/non-member examples and evaluate attack performance against an appropriate chance baseline.
