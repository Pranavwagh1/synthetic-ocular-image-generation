# Notebook 11 — GAN vs Diffusion Comparison

## Experimental setup
- GAN generated images found: **38**
- Diffusion generated images found: **17**
- Real reference images evaluated: **500**
- Total images successfully evaluated: **555**
- Evaluation errors: **0**

## Measured results
| group          |   n_images |   brightness_mean |   brightness_std |   contrast_mean |   contrast_std |   dynamic_range_mean |   dynamic_range_std |   gradient_energy_mean |   gradient_energy_std |   laplacian_variance_mean |   laplacian_variance_std |   high_frequency_residual_mean |   high_frequency_residual_std |
|:---------------|-----------:|------------------:|-----------------:|----------------:|---------------:|---------------------:|--------------------:|-----------------------:|----------------------:|--------------------------:|-------------------------:|-------------------------------:|------------------------------:|
| GAN            |         38 |           132.545 |          14.8501 |         49.5577 |        10.0387 |              233.079 |             16.8326 |                832.168 |              295.587  |                  6591.96  |                 1494.43  |                        13.045  |                        2.0942 |
| Diffusion      |         17 |           125.906 |           7.8537 |         27.9879 |         5.2938 |              174.823 |             24.694  |                141.06  |               98.6377 |                   750.15  |                  348.544 |                         4.7686 |                        0.8312 |
| Real reference |        500 |           147.83  |          23.4428 |         61.3424 |         8.2831 |              254.406 |              3.8117 |                171.342 |               65.8491 |                   758.596 |                  259.495 |                         3.8749 |                        0.7084 |

## Metric interpretation
- **brightness**: GAN has the higher mean brightness (132.5454 GAN vs 125.9060 diffusion). Real-reference mean: 147.8298.
- **contrast**: GAN has the higher mean contrast (49.5577 GAN vs 27.9879 diffusion). Real-reference mean: 61.3424.
- **dynamic_range**: GAN has the higher mean dynamic range (233.0789 GAN vs 174.8235 diffusion). Real-reference mean: 254.4060.
- **gradient_energy**: GAN has the higher mean gradient energy (832.1678 GAN vs 141.0600 diffusion). Real-reference mean: 171.3417.
- **laplacian_variance**: GAN has the higher mean laplacian variance (6591.9592 GAN vs 750.1502 diffusion). Real-reference mean: 758.5965.
- **high_frequency_residual**: GAN has the higher mean high frequency residual (13.0450 GAN vs 4.7686 diffusion). Real-reference mean: 3.8749.

## Important limitations
- These are low-level image-statistics proxies, not a validated image-quality benchmark.
- A higher metric value does not necessarily indicate a better generated image.
- Visual similarity and semantic diversity have not been validated by expert review or a pretrained feature-space metric.
- No verified labels are available here to establish contact-lens classification or iris identity performance.
- Unequal and small generated sample counts limit the strength of the comparison.

## Conclusion
This notebook compares the available GAN and diffusion samples using visual grids and low-level grayscale image statistics. The numeric results describe only the evaluated files and do not establish that either generator is superior in realism, diversity, identity preservation, privacy, or downstream recognition utility. Use the actual summary table and plots when reporting results.