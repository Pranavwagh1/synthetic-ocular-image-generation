# Notebook 10 — Recognition with Augmented Data: Conclusion

## Objective
Train an exploratory ResNet18 model using the real-image portion of the consolidated NDCLD15 dataset and evaluate it on held-out real images.

## Configuration
- Model: ResNet18
- Epochs: 3
- Input resolution: 128 × 128
- Proxy classes: 322
- Training images: 4213
- Validation images: 1000
- Test images: 1003
- Device: cuda

## Results
- Test loss: 2.7872
- Test accuracy: 36.4905%
- Test samples: 1003

## Critical limitations
The labels used here are unverified filename-derived proxy labels. They are not verified contact-lens classes or verified biometric identities. Therefore, the reported test accuracy is only an exploratory proxy-label result and must not be presented as valid contact-lens recognition accuracy.

Although traditional augmentation files are available, this experiment uses only real images in its train/validation/test splits. It does not yet establish whether traditional, GAN, or diffusion augmentation improves performance. A valid comparison requires verified labels and identical, leakage-safe splits across experiments.

## Conclusion
The exploratory model training and held-out evaluation completed. Results are documented for reproducibility, but no claim about contact-lens classification performance or augmentation benefit can be made from this proxy-label experiment.
