# Notebook 07 — Diffusion Model Training: Preliminary Conclusion

- Source images: 6,233
- Resolution: 64 × 64, grayscale
- Epochs: 5
- Diffusion timesteps: 200
- Final noise-prediction MSE: 0.074839
- Hardware: cuda; GPUs available: 2
- U-Net shape test: passed

An unconditional DDPM was trained on the available image subset. Verified
contact-lens labels were unavailable, so generation was not class-conditional.
Training loss alone does not establish realism, diversity, privacy, or
downstream utility. Generated samples require separate evaluation.
