# Notebook 14 — Result Visualization and Ablation Studies

## Objective
This notebook consolidates available results from the earlier project notebooks into visual summaries, artifact inventory, and a comparison table describing which comparisons are valid.

## Recognition Results
| experiment              |   test_accuracy_percent | label_type                    | trained_with_generated_augmentation   | interpretation                                                    |
|:------------------------|------------------------:|:------------------------------|:--------------------------------------|:------------------------------------------------------------------|
| Notebook 04 baseline    |                 30.18   | Filename-derived proxy labels | False                                 | Exploratory proxy-label result; not verified identity recognition |
| Notebook 10 recognition |                 36.4905 | Filename-derived proxy labels | False                                 | Real images only; not an augmentation-benefit experiment          |

These recognition scores use filename-derived proxy labels, not verified iris identity labels. Notebook 10 trained on real images only, so the difference between these scores does not demonstrate the benefit of augmentation.

## Generator Comparison
Generator metric source: **Notebook 11**

The generated-image plots compare low-level brightness, contrast, dynamic range, gradient energy, Laplacian variance, and high-frequency residual where results are available. These statistics describe image appearance but do not establish perceptual realism or semantic diversity.

## Privacy and Membership-Inference Findings
- Notebook 12 simulated randomly assigned membership and achieved approximately chance-level performance (accuracy 49.8667%, ROC-AUC 0.49994).
- Notebook 13 found no exact normalized matches among 55 evaluated generated images and a sampled set of 1,500 real images.
- Neither experiment establishes that the trained recognition model is privacy-safe or privacy-vulnerable.

## Ablation-Study Validity
The comparison table distinguishes exploratory results from controlled experiments. No controlled augmentation ablation is claimed because a matched recognition experiment using identical splits and training settings with and without augmentation has not been completed.

## Limitations
- No verified ground-truth contact-lens labels or iris identities were available in this workflow.
- Recognition accuracy based on filename-derived proxy labels is not a validated biometric metric.
- GAN and diffusion sample counts were small and unequal.
- Privacy screening used simple similarity metrics and a sampled real reference set.
- Results from different splits, label definitions, or evaluation settings should not be directly interpreted as causal improvements.

## Conclusion
Notebook 14 provides a consolidated visual summary and transparent comparability assessment of the results produced so far. The available evidence supports exploratory analysis of image generation, proxy-label recognition, and similarity screening, but does not support claims of verified identity recognition, augmentation benefit, or formal privacy protection.
