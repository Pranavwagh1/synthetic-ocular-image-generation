# Notebook 03 — Ocular Image Quality Assessment

- Images discovered: **6,233**
- Images assessed successfully: **6,233**
- Assessment errors: **0**

Metrics include mean brightness, grayscale contrast, dynamic range, gradient energy,
Laplacian variance, and an exploratory high-frequency residual proxy. Distribution
plots, percentile-based review flags, and a contact sheet of low-sharpness candidates
were generated.

These indicators are exploratory. The percentile flags are relative to this dataset
and should not automatically be treated as image rejection criteria. Quality metrics
also do not validate identity labels.
