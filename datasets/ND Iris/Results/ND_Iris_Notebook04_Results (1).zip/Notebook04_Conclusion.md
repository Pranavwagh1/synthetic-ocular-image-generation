# Notebook 04 — Exploratory Baseline: Results and Limitations

## Results
- Images used: 6,233
- Unverified filename-prefix classes: 324
- Training images: 4,363
- Validation images: 935
- Test images: 935
- Epochs: 3
- Best validation accuracy on proxy labels: 0.2920
- Test accuracy on proxy labels: 0.2449
- Test loss: 3.6978
- Device: cuda; GPUs available: 2

## Critical limitations
No verified contact-lens class annotations were available. The target was therefore
constructed from the numeric filename prefix before the letter `d`. This is an
unverified proxy, not a No Lens / Soft Lens / Textured Lens label and not a verified
person/eye identity label.

The split is image-level and may contain related filename groups in multiple splits.
Consequently, these metrics describe only prediction of the proxy labels and must not
be presented as contact-lens detection or biometric identity recognition performance.

## Outputs
- Exploratory labeled manifest and class mapping in the checkpoint
- Training history CSV and accuracy plot
- Model checkpoint
- Test predictions CSV and classification report JSON
- Metrics JSON
- This conclusion report

## Conclusion
The notebook completed an exploratory ResNet18 experiment using the available images.
The experiment demonstrates the training pipeline runs, but it does not establish
contact-lens classification performance. Verified annotations and a suitable split
are required for that claim.
