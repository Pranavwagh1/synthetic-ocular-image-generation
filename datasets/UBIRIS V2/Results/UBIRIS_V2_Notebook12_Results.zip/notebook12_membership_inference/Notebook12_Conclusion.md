# Notebook 12 — Membership Inference Attack

## Objective
A loss-based membership inference experiment was conducted to investigate
whether the models' true-label losses distinguish training images (members)
from held-out test images (non-members).

## Method
For each saved recognition model, true-label cross-entropy loss and
true-label prediction confidence were measured for training and test images.
The attack score was defined as negative true-label loss, so higher scores
indicate greater member-likeness. ROC-AUC was used to summarize separation.

## Interpretation
Use the generated summary CSV and JSON for the measured results. An AUC near
0.5 indicates little separation by this particular score. A higher AUC indicates
greater distinguishability under this experimental setup. Neither outcome alone
proves or rules out a privacy breach.

## Limitations
The dataset split is image-level, not subject-disjoint, and identities can
appear in both member and non-member groups. The threshold-based accuracy,
precision, recall, and F1 are exploratory because the threshold is selected on
the evaluated groups. This is a limited loss-based attack, not a comprehensive
privacy audit, identity reconstruction test, or proof of real-world leakage.

## Conclusion
The results characterize the degree to which training membership is
distinguishable using true-label loss for the two saved models under this
dataset split. Any privacy interpretation must remain limited to this attack,
these checkpoints, and this evaluation protocol.
