# Final Deployment and Demo — UBIRIS V2

## Demo
This notebook loads the saved baseline and augmented ResNet18 checkpoints,
preprocesses one available grayscale ocular image to 224x224, and displays
each model's predicted class index and top-class confidence.

## Intended use
This is a research demonstration only. The output is not a verified identity
match and must not be used for authentication, access control, or consequential
decisions.

## Limitations
- Labels were parsed from filenames and have not been independently verified.
- The original train/validation/test split is image-level, not subject-disjoint.
- Notebook 12 reported very low recognition accuracy when reloading the
  checkpoints, inconsistent with the earlier saved evaluation results.
- A high softmax confidence does not establish correctness, identity, fairness,
  robustness, or privacy.
- GAN and diffusion previews did not demonstrate convincing ocular image
  generation in the saved experiments.
- This notebook does not deploy a web service or production authentication API.

## Reproducibility
The demo records the input image, predicted class index, top-class confidence,
and model used. The original model checkpoints remain separate from this ZIP.
