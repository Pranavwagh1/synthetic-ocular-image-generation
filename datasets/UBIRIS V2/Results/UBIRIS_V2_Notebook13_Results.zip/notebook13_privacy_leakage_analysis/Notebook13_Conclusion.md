# Notebook 13 — Privacy Leakage Analysis

## Objective
Analyze the existing loss-based membership-inference results for the UBIRIS V2
baseline and augmented recognition models.

## Results
| Model | Attack ROC-AUC | Mean member loss | Mean non-member loss |
|---|---:|---:|---:|
| baseline | 0.4929 | 12.0663 | 11.9397 |\n| augmented | 0.5168 | 13.9285 | 14.3301 |\n
## Interpretation
- Baseline membership attack ROC-AUC: 0.4929.
- Augmented-model membership attack ROC-AUC: 0.5168.
- An ROC-AUC near 0.5 indicates little member/non-member separation by this
  particular score under this experiment.
- The augmented result is slightly above 0.5, but this alone does not establish
  a confirmed privacy breach or meaningful real-world attack capability.
- The threshold-based accuracy, precision, recall, and F1 from Notebook 12
  used a threshold selected on the evaluated groups. They are exploratory and
  should not be treated as independent generalization estimates.

## Important limitations
1. The split is image-level, not subject-disjoint; identities may occur in both
   groups.
2. Membership scores are based on negative true-label cross-entropy loss.
3. This is one attack method, not a comprehensive privacy audit.
4. The very low reported recognition accuracies in Notebook 12 warrant checking
   checkpoint loading, class-label mapping, preprocessing, and test split
   consistency before drawing wider conclusions.
5. This experiment does not test identity reconstruction, attribute inference,
   model inversion, or leakage from individual GAN/diffusion samples.
6. These results do not prove that either model is private or non-private.

## Conclusion
The tested loss-based attack showed near-random membership separation for the
baseline model and only a small above-random AUC for the augmented model.
The result is limited to the present evaluation setup. Stronger claims require
a carefully held-out attack evaluation, subject-disjoint splits where suitable,
validated model evaluation, and additional attack methods.

Notebook 12's original results are retained as the source of these metrics.
