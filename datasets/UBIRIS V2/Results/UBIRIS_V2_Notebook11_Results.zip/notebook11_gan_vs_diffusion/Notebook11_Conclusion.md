# Notebook 11 — GAN vs. Diffusion Comparison

## Objective
This experiment compared the training behavior and saved preview observations
of a GAN and a denoising diffusion probabilistic model (DDPM) trained using
UBIRIS V2 data.

## Training Results
- **GAN:** trained for 5 epochs, with 132 batches per epoch. The final generator
  loss was 2.144427 and the final discriminator loss was 0.399675.
- **Diffusion (DDPM):** trained for 6 epochs, with 265 batches per epoch.
  The mean training loss decreased from 0.071654 in epoch 1 to 0.016369
  in epoch 6.

The loss values are not directly comparable because GAN and diffusion models
optimize different objectives.

## Qualitative Observations
- GAN preview grids contained repetitive, grid-like patterns and artifacts.
- Diffusion preview images remained cloudy/noisy and were not recognizably ocular.

## Quality and Diversity Evaluation
The available exploratory image descriptors were calculated on real images,
traditionally augmented images, and composite GAN/diffusion preview grids.
The generated-model measurements therefore describe preview grids rather than
individual synthetic images. They cannot establish a reliable per-image
quality or diversity ranking.

## Limitations
1. Individual GAN- and diffusion-generated images were not available for
   quantitative evaluation in this comparison.
2. These experiments do not establish identity preservation, privacy protection,
   or improved recognition accuracy from GAN or diffusion augmentation.
3. Training losses alone do not establish perceptual image quality.
4. The experiments were limited in training duration and should be considered
   preliminary.

## Conclusion
Both generative approaches were trained, but neither produced convincing
ocular samples in the saved previews. The diffusion model showed a decreasing
training loss, while the GAN showed changing generator and discriminator
losses. These observations are useful diagnostic findings, not proof that one
approach is superior. Future evaluation requires individual generated images,
validated image-quality and diversity measures, identity-preservation testing,
and controlled recognition experiments.

The findings are reported as observed, without claiming successful synthetic
ocular generation or demonstrated privacy benefits.
