# Notebook 14 — Result Visualization and Ablation Studies

## Recognition comparison

| Experiment | Test accuracy | Macro precision | Macro recall | Macro F1 | Test loss |
|---|---:|---:|---:|---:|---:|
| Baseline | 0.4743 | 0.4296 | 0.4421 | 0.3897 | 1.9628 |
| Real + traditional augmentation | 0.9332 | 0.9534 | 0.9392 | 0.9351 | 0.2138 |

Observed difference in test accuracy: 45.89 percentage points.
Observed difference in macro F1: 54.54 percentage points.

These are comparisons between recorded experiments, not a controlled causal
ablation. The augmented experiment uses more training examples, and other
training details/checkpoints must be verified before attributing the full
difference to augmentation alone.

## GAN and diffusion
- GAN training: 5 recorded epochs.
- Diffusion training: 6 recorded epochs.
- The saved GAN preview was described as repetitive/grid-like with artifacts.
- The saved diffusion preview was described as cloudy/noisy and not recognizably ocular.
- Decreasing training loss alone does not demonstrate realistic images or
  identity preservation.

## Membership inference
- baseline: ROC-AUC 0.4929
- augmented: ROC-AUC 0.5168

ROC-AUC near 0.5 indicates little member/non-member separation by this score
under the tested setup. It does not prove privacy.

## Quality/diversity
Quality descriptors are exploratory. Composite GAN/diffusion preview-grid
statistics are not treated as individual-image quality metrics.

## Limitations
- The data split is image-level, not subject-disjoint.
- Identity labels were parsed from filenames and not independently verified.
- GAN and diffusion individual generated samples were unavailable for a fair
  image-level recognition ablation.
- No confidence intervals or repeated random-seed runs were performed here.
- Notebook 12 reported extremely low prediction accuracy while Notebook 10
  reported much higher accuracy. This inconsistency requires auditing
  checkpoint loading, preprocessing, class mapping, and evaluation split.
- This notebook visualizes existing outputs; it does not retrain models or
  establish causal effects.

## Conclusion
Traditional augmentation's recorded experiment achieved higher recognition
metrics than the recorded baseline, but the magnitude of the difference needs
independent reproducibility checks. The saved GAN and diffusion experiments
did not produce convincing ocular samples in their previews. The privacy
results are limited to one loss-based membership attack. Subject-disjoint
evaluation, stronger generated-image metrics, and repeatable controlled
experiments are needed before claiming improved biometric robustness or privacy.
